package scraper

// Scraper ...
func Scraper() string {
	return "Hello world."
}
